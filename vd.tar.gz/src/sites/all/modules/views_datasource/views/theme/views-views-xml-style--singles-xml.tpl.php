<?php
print "views-views-xml-style--singles-xml.tpl.php";